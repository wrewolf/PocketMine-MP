#!/bin/bash
php PocketMine-MP.php &
cat > logs/console.in